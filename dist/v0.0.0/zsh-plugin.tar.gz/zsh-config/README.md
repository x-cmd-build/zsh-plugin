# zsh-config

Enhanced configuration (history and key-bindings) for the shell zsh

Part of the configure inspired by [ohmyzsh](https://github.com/ohmyzsh/ohmyzsh/tree/master)
